"""
Streamlit GUI for the Company Junction deduplication pipeline.

This app provides an interactive interface for:
- Loading review-ready data from pipeline output
- Filtering and reviewing duplicate groups
- Exporting filtered results
"""

import streamlit as st
import pandas as pd
import sys
from pathlib import Path
import json
import os

# Add src directory to path for imports
sys.path.append(str(Path(__file__).parent.parent / 'src'))

from utils import setup_logging


def load_review_data():
    """Load review-ready data from pipeline output."""
    review_path = "data/processed/review_ready.csv"
    
    if not os.path.exists(review_path):
        return None
    
    try:
        df = pd.read_csv(review_path)
        return df
    except Exception as e:
        st.error(f"Error loading review data: {e}")
        return None


def parse_merge_preview(preview_json):
    """Parse merge preview JSON for display."""
    if not preview_json or pd.isna(preview_json):
        return None
    
    try:
        return json.loads(preview_json)
    except:
        return None


def main():
    """Main Streamlit application."""
    st.set_page_config(
        page_title="Company Junction Deduplication Review",
        page_icon="🔗",
        layout="wide"
    )
    
    st.title("🔗 Company Junction Deduplication Review")
    st.markdown("Review and filter duplicate detection results from the pipeline.")
    
    # Setup logging
    setup_logging()
    
    # Load review data
    df = load_review_data()
    
    if df is None:
        st.warning("""
        ## No Review Data Found
        
        Please run the pipeline first to generate review data:
        
        ```bash
        python src/cleaning.py --input data/raw/company_junction_range_01.csv --outdir data/processed --config config/settings.yaml
        ```
        
        This will create `data/processed/review_ready.csv` for review.
        """)
        return
    
    # Sidebar filters
    st.sidebar.header("Filters")
    
    # Min score filter
    min_score = st.sidebar.slider(
        "Minimum Score to Primary",
        min_value=0.0,
        max_value=100.0,
        value=0.0,
        step=1.0
    )
    
    # Disposition filter
    dispositions = df['Disposition'].unique()
    selected_dispositions = st.sidebar.multiselect(
        "Disposition",
        options=dispositions,
        default=dispositions
    )
    
    # Suffix mismatch filter
    show_suffix_mismatch = st.sidebar.checkbox("Show Suffix Mismatches Only", value=False)
    
    # Group size filter
    group_sizes = df['group_id'].value_counts()
    min_group_size = st.sidebar.slider(
        "Minimum Group Size",
        min_value=1,
        max_value=int(group_sizes.max()),
        value=1
    )
    
    # Apply filters
    filtered_df = df.copy()
    
    if min_score > 0:
        filtered_df = filtered_df[filtered_df['score_to_primary'] >= min_score]
    
    if selected_dispositions:
        filtered_df = filtered_df[filtered_df['Disposition'].isin(selected_dispositions)]
    
    if show_suffix_mismatch:
        # Filter for groups with suffix mismatches
        suffix_mismatch_groups = []
        for group_id in filtered_df['group_id'].unique():
            group_data = filtered_df[filtered_df['group_id'] == group_id]
            suffix_classes = group_data['suffix_class'].unique()
            if len(suffix_classes) > 1:
                suffix_mismatch_groups.append(group_id)
        filtered_df = filtered_df[filtered_df['group_id'].isin(suffix_mismatch_groups)]
    
    # Filter by group size
    group_sizes_filtered = filtered_df['group_id'].value_counts()
    valid_groups = group_sizes_filtered[group_sizes_filtered >= min_group_size].index
    filtered_df = filtered_df[filtered_df['group_id'].isin(valid_groups)]
    
    # Display summary
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Records", len(filtered_df))
    with col2:
        st.metric("Groups", len(filtered_df['group_id'].unique()))
    with col3:
        st.metric("Primary Records", filtered_df['is_primary'].sum())
    with col4:
        st.metric("Avg Score to Primary", f"{filtered_df['score_to_primary'].mean():.1f}")
    
    # Display disposition summary
    st.subheader("Disposition Summary")
    disposition_counts = filtered_df['Disposition'].value_counts()
    st.bar_chart(disposition_counts)
    
    # Display groups
    st.subheader("Duplicate Groups")
    
    # Group by group_id and display each group
    for group_id in sorted(filtered_df['group_id'].unique()):
        group_data = filtered_df[filtered_df['group_id'] == group_id].copy()
        
        # Parse merge preview for this group
        merge_preview = None
        for _, row in group_data.iterrows():
            if row['merge_preview_json']:
                merge_preview = parse_merge_preview(row['merge_preview_json'])
                break
        
        # Group header
        primary_record = group_data[group_data['is_primary']].iloc[0] if group_data['is_primary'].any() else group_data.iloc[0]
        
        with st.expander(f"Group {group_id}: {primary_record['Account Name']} ({len(group_data)} records)"):
            col1, col2 = st.columns([2, 1])
            
            with col1:
                # Display group table
                display_cols = [
                    'Account Name', 'Account ID', 'Relationship', 'Disposition',
                    'is_primary', 'score_to_primary', 'suffix_class'
                ]
                display_cols = [col for col in display_cols if col in group_data.columns]
                
                st.dataframe(group_data[display_cols], use_container_width=True)
            
            with col2:
                # Display badges and metadata
                st.write("**Group Info:**")
                
                # Suffix mismatch badge
                suffix_classes = group_data['suffix_class'].unique()
                if len(suffix_classes) > 1:
                    st.error("⚠️ Suffix Mismatch")
                else:
                    st.success(f"✅ {suffix_classes[0]}")
                
                # Blacklist hits
                blacklist_hits = group_data['Account Name'].str.lower().str.contains('|'.join([
                    'pnc is not sure', 'unsure', 'unknown', '1099', 'none', 'n/a', 'test'
                ])).sum()
                
                if blacklist_hits > 0:
                    st.warning(f"⚠️ {blacklist_hits} blacklist hits")
                
                # Primary selection reason
                if merge_preview and 'primary_record' in merge_preview:
                    primary_info = merge_preview['primary_record']
                    st.write(f"**Primary:** {primary_info.get('account_id', 'N/A')}")
                    st.write(f"**Rank:** {primary_info.get('relationship_rank', 'N/A')}")
            
            # Display merge preview if available
            if merge_preview and 'field_comparisons' in merge_preview:
                st.write("**Field Conflicts:**")
                
                conflicts = []
                for field, comparison in merge_preview['field_comparisons'].items():
                    if comparison.get('has_conflict', False):
                        conflicts.append({
                            'field': field,
                            'primary_value': comparison.get('primary_value', ''),
                            'alternatives': comparison.get('alternative_values', [])
                        })
                
                if conflicts:
                    for conflict in conflicts:
                        st.write(f"**{conflict['field']}:**")
                        st.write(f"  Primary: {conflict['primary_value']}")
                        st.write(f"  Alternatives: {', '.join(conflict['alternatives'])}")
                else:
                    st.success("✅ No field conflicts")
    
    # Export functionality
    st.subheader("Export")
    
    if st.button("Export Filtered Data"):
        # Create download link
        csv = filtered_df.to_csv(index=False)
        st.download_button(
            label="Download CSV",
            data=csv,
            file_name=f"filtered_review_data_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )


if __name__ == "__main__":
    main()
