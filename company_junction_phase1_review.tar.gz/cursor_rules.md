# Cursor Rules

## Project Structure
- Follow Cookiecutter Data Science foldering:
  - `data/raw` = raw exports from Salesforce
  - `data/interim` = temporary cleaning outputs
  - `data/processed` = final merged datasets
  - `src/` = pipeline code (cleaning, utils, salesforce CLI integration)
  - `app/` = Streamlit GUI
  - `tests/` = unit tests
  - `docs/` = additional documentation
- Keep heavy logic in `src/`, not in `app/`.
- Optional `config/` for `settings.yaml`, `logging.conf`.

## Code Standards
- Always create/update guardrail files: README.md, CHANGELOG.md
- Keep test files in `tests/` directory
- Use type hints in Python functions
- Add docstrings to all functions and classes
- Follow PEP 8 style guidelines

## Data Pipeline Principles
- Ensure reproducibility: pipeline always re-runs cleanly from `data/raw/`
- Maintain data lineage: track transformations from raw to processed
- Use logging for debugging and audit trails
- Validate data at each step of the pipeline
- Do **not** commit large data. Only small samples under `tests/fixtures/`.

## Development Workflow
- Install from `requirements.txt` only.
- All new features must include at least one test in `tests/`.
- Update `CHANGELOG.md` for any significant changes
- Keep dependencies minimal and well-documented
- Document any configuration requirements

## Critical Review
- Be critical of prompts: if unclear, provide feedback before executing
- Question assumptions about data formats and requirements
- Validate that solutions are maintainable and scalable
- Consider edge cases and error handling

## File Naming Conventions
- Use `snake_case` for Python files/functions.
- Use descriptive names that indicate purpose
- Include timestamps in processed data filenames
- Keep file paths relative to project root

---

## Phase 1 Rules (Company Junction Deduplication)

- **Scope:** Read-only first pass review. No Salesforce writes. Split detection is **deferred to Phase 2**.
- **Normalization (src/normalize.py):**
  - Preserve legal suffix differences (INC vs LLC etc.).
  - Map symbols: `&→and`, `/→space`, `-→space`, `@→at`, `+→plus`; collapse whitespace.
  - Numeric style unify: `20-20`, `20/20`, `20 20` → `20 20`.
  - Extract trailing suffix into `suffix_class`; compute `name_core` without suffix for candidate generation.
- **Similarity (src/similarity.py):**
  - Use RapidFuzz (`token_sort_ratio`, `token_set_ratio`) + Jaccard on `name_core`.
  - Composite score: `0.45*ratio_name + 0.35*ratio_set + 20*jaccard`, with penalties:
    - `suffix_mismatch: 25`
    - `num_style_mismatch: 5`
  - Thresholds (from `config/settings.yaml`): `high=92`, `medium=84`.
  - If `suffix_match=False`, do not auto-accept; mark for **Verify**.
  - Build groups as connected components where `suffix_match=True` and `score ≥ medium`.
- **Survivorship (src/survivorship.py):**
  - Primary selection order:
    1) Lowest Relationship rank (from `config/relationship_ranks.csv`)
    2) Earliest Created Date (Excel serials supported)
    3) Smallest Account ID (lexicographic)
  - Provide a lightweight `merge_preview_json` (no writebacks).
- **Disposition (src/disposition.py):**
  - Values: `Keep`, `Update`, `Delete`, `Verify`.
  - `Delete` if name matches blacklist (`pnc is not sure`, `1099`, etc.).
  - Suffix mismatch within a group ⇒ `Verify`.
  - Primary in group ⇒ `Keep`; non-primary ⇒ `Update`.
  - Singleton clean ⇒ `Keep`; suspicious ⇒ `Verify`.
  - LLM gate is optional and **disabled by default** (Phase 2 consideration).
- **Artifacts:**
  - `data/interim/*.parquet` and `data/processed/review_ready.csv`.
- **Tests:**
  - Include unit tests for normalization, similarity, grouping/survivorship, and disposition. Match thresholds from config.